
import math
value = int(input("Enter the number"))
num = [int(d) for d in str(value)]
sum = 0
for i in range(0,len(num)):
    sum = sum + math.pow(num[i],len(num))

if sum == value:
    print("given number is armstrong number")
else:
    print("given number is not armstrong number")
